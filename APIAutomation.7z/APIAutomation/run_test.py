# !/usr/bin/python
# -*- coding: utf-8 -*-

import os
import unittest

from common.common_fun import CommomFun
from common.logger_handler import logger
from common.yaml_handler import yaml_data
from libs.BeautifulReport import BeautifulReport
from common.project_path import p_path
from test_case import ApiTest
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import Header



def add_case(test_class):
    """
    加载的测试用例
    :param test_class: 测试类
    :return: 测试套件
    """
    loader = unittest.TestLoader()  # 用例加载器
    test = loader.loadTestsFromModule(test_class)  # 加载测试模块
    suit = unittest.TestSuite()  # 测试套件
    suit.addTest(test)  # 测试类添加到测试套件中
    return suit


def send_mail(file_new, title):
        """
        :param title: 邮件标题
        :param file_new: 文件名 -> str
        :return:
        """
        emailReceiver = yaml_data['email']['email_receiver']

        # 发送邮件的
        smtpserver = yaml_data['email']['smtpserver']
        email_user = 'testman0519@163.com'
        password = 'CTNJVLXRMHRJMIXG'
        subject = title
        # 创建一个带附件的实例
        message = MIMEMultipart()
        message['From'] = email_user
        message['To'] = ",".join(emailReceiver)
        message['Subject'] = Header(subject, 'utf-8')
        # 邮件正文内容
        message.attach(MIMEText(subject, 'plain', 'utf-8'))

        # 构造附件1，传送reports目录下的报告文件
        with open(file_new, 'rb') as report:
            att1 = MIMEText(report.read(), 'base64', 'utf-8')
            att1["Content-Type"] = 'application/octet-stream'
            # 这里的filename可以任意写，写什么名字，邮件中显示什么名字
            att1["Content-Disposition"] = f'attachment; filename=report.html'
            message.attach(att1)

        # 构造附件2，发送log日志目录下的报告文件
        tool = CommomFun()
        log_file_path = tool.get_log_path()
        if log_file_path:
            with open(log_file_path, 'rb') as log:
                att2 = MIMEText(log.read(), 'base64', 'utf-8')
                att2["Content-Type"] = 'application/octet-stream'
                # 这里的filename可以任意写，写什么名字，邮件中显示什么名字
                att2["Content-Disposition"] = f'attachment; filename=log.txt'
                message.attach(att2)

        # smtp = smtplib.SMTP_SSL(smtpserver, port=465)
        smtp = smtplib.SMTP_SSL(smtpserver)
        try:
            logger.info('邮件发送中')
            smtp.login(email_user, password)
            smtp.sendmail(email_user, emailReceiver, message.as_string())
        except Exception as e:
            logger.error(f'邮件发送失败,报错是{e}')
            smtp.quit()
        else:
            logger.info('邮件发送完毕')
            smtp.quit()

def run_test():
    tool = CommomFun()
    # 删除旧的日志文件
    tool.delete_log()

    # 删除旧的测试报告文件
    try:
        os.remove(os.path.join(p_path.TEMPLATES_PATH, 'report.html'))
    except Exception as e:
        logger.warning(f'测试报告文件删除失败 报错是{e}')

    report_path = p_path.TEMPLATES_PATH
    suite = add_case(ApiTest)
    result = BeautifulReport(suite)
    result.report(filename='report.html',
                  description='Api Test Report', report_dir=report_path,
                  theme="theme_cyan")
    report = os.path.join(report_path, "report.html")
    # send_mail(report, f'Api Api Test Report')

run_test()
