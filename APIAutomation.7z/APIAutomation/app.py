# !/usr/bin/python
# -*- coding: utf-8 -*-


import os
import threading
from common.common_fun import CommomFun
from common.logger_handler import logger
from run_test import run_test
from flask import Flask, send_file, send_from_directory
from common.project_path import p_path


class FlaskApp(Flask):

    __instance = None

    def __new__(cls, *args, **kwargs):
        if not cls.__instance:
            cls.__instance = super().__new__(cls)
        return cls.__instance


    def __init__(self, *args, **kwargs):
        super(FlaskApp, self).__init__(*args, **kwargs)
        self._start_run_test_case()

    def _start_run_test_case(self):
        def run_job():
            run_test()

        t1 = threading.Thread(target=run_job)
        t1.start()


app = FlaskApp(__name__)
tools = CommomFun()

@app.route('/')
def hello_world():
    return 'hello Api'


@app.route('/report')
def report():
    # return render_template('/report.html')
    report_path = os.path.join(p_path.TEMPLATES_PATH, 'report.html')
    if os.path.exists(report_path):
        return send_file(os.path.join(p_path.TEMPLATES_PATH, 'report.html'))
    else:
        return 'api test is running please wait... '


@app.route('/log')
def log():
    logger.info(f'日志文件夹下文件：{os.listdir(p_path.LOG_PATH)}')
    logger.info(f'当前时间：{tools.get_now_time()}')
    logger.info(f'当前日期：{tools.get_now_time()[:10]}')
    if tools.get_log_path():
        for file_name in os.listdir(p_path.LOG_PATH):
            return send_from_directory(p_path.LOG_PATH, file_name, as_attachment=True)
    else:
        return 'api test is running please wait... '



@app.route('/test')
def test_run():
    def run_job():
        run_test()
    t2 = threading.Thread(target=run_job)
    t2.start()
    return 'api test is running.  please visit /report to get the test report after a few minutes'


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8080)
