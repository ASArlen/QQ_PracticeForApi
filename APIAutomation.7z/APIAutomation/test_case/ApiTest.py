import os
import unittest
from common.base_case import APICase
from common.common_fun import CommomFun
from common.excel_handler import ExcelHandler
from common.logger_handler import logger
from common.param_replace import replace_label
from common.project_path import p_path
from common.yaml_handler import yaml_data, yaml_handle
from libs.ddt import data, ddt
import json
import jsonpath


@ddt
class TestApi(APICase):
    # -*- 读取配置文件 -*-
    # excel文件完整路径
    file_path = os.path.join(p_path.DATA_PATH, yaml_data["case_info"]["file_name"])
    # sheet页名称
    sheet_name = yaml_data["case_info"]["sheet_name"]
    # url 基本地址
    base_url = yaml_data["case_info"]["base_url"]
    # -*- excel操作 -*-
    xls = ExcelHandler(file_path, sheet_name)
    test_data = xls.read()
    # # 下载文件相关
    # xls_down_load_data = ExcelHandler(file_path, "file_down_load")
    # file_down_load_data = xls_down_load_data.read()
    # # 上传文件相关
    # xls_up_load_data = ExcelHandler(file_path, "file_up_load")
    # file_up_load_data = xls_up_load_data.read()

    # -*- 工具类 -*-
    tools = CommomFun()


    # @unittest.skipIf(not yaml_data['case_info']['run_api_test_case'], '配置文件设置跳过')
    @data(*test_data)
    def test_api(self, test_case):
        # 判断接口是否跳过 调试时使用 1跳过 不填写或其他不跳过
        try:
            if test_case["skip"] == 1:
                logger.info(f'【test_case["title"]】接口跳过执行')
                return
        except:
            pass
        # 接口名
        api_name = test_case["title"]
        logger.info(f'【{api_name}】接口调用开始')
        # 请求方法
        req_method = test_case["method"]
        logger.info(f'【{api_name}】接口请求方式：{req_method}')
        # 请求路径拼接
        req_url = self.base_url + self.replace(test_case["url"])
        logger.info(f'【{api_name}】接口请求路径：{req_url}')
        # http请求头
        http_headers = json.loads(replace_label(test_case["headers"]))
        # 请求数据
        if req_method == 'post':
            req_data = json.loads(self.replace(self.tools.clear_text(test_case['data'])))
            # req_data = replace_label(self.tools.clear_text(test_case['data']))
            logger.info(f'【{api_name}】接口请求数据：{json.dumps(req_data)}')
        else:
            # get请求不需要构造参数
            req_data = None
            logger.info(f'【{api_name}】接口请求数据：{req_url}')

        # 获取返回数据
        response = self.req.json(method=req_method.lower(),
                                 url=req_url,
                                 json=req_data,
                                 api_name=api_name,
                                 headers=http_headers
                                 )
        # 返回值关联
        if test_case['extractor']:
            extractor = json.loads(test_case['extractor'])
        else:
            extractor = {}
        self.extract(extractor, response)
        # 接口值返回转json
        response_json = json.dumps(response)
        logger.info(f'【{api_name}】接口请求返回：{response_json}')
        # 如果多个预期结果以,分割 循环断言
        expects = self.tools.clear_text(test_case["expected"]).split(',')
        # 接口断言
        for expect in expects:
            # 接口返回json格式数据，:后有空格，断言加空格处理
            expect = expect.replace(':"', ': "')
            try:
                self.assertIn(expect, response_json)
            except Exception as e:
                logger.error(f'【{api_name}】接口断言失败！！！预期结果({expect})不在接口返回数据中，报错是：{e}')
                raise e

        logger.info(f'【{api_name}】接口测试通过')

