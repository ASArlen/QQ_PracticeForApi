#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File   : __init__.py.py
# @Author : mocobk
# @Email  : mailmzb@qq.com
# @Time   : 2019/3/20 21:01

from .BeautifulReport import BeautifulReport


__all__ = ['BeautifulReport']