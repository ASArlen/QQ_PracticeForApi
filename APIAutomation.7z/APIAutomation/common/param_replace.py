"""
excel文件读取数据 动态替换不可写死参数
"""
import json
import random

from common.common_fun import CommomFun
import re

# -*- 时间相关 -*-
from common.yaml_handler import yaml_data

tools = CommomFun()
endTime = tools.get_dealy_time()
startTime = tools.get_now_time()


class Context:
    """保存临时替换的数据"""

    def __init__(self):
        pass

    @property
    def EndTime(self):
        return tools.get_dealy_time(30)[:10]

    @property
    def StartTime(self):
        return tools.get_now_time()[:10]

    @property
    def now(self):
        return tools.get_now_time()

    @property
    def tomorrow(self):
        return tools.get_dealy_time()

    @property
    def yestarday(self):
        return tools.get_before_time(1)[:10]

    @property
    def name_info(self):
        return 'apitest' + tools.get_timestamp()

    @property
    def random_str(self, str_lenth=13):
        seed = "1234567890abcdefghijklmnopqrstuvwxyz"
        tmp = []
        for i in range(str_lenth):
            tmp.append(random.choice(seed))
        return ''.join(tmp)


# a = Context()
# a.yestarday

def replace_label(target, mark="#"):  # 字符串:replace.
    """用 data 替换 target 里的标签。
    {"Authorization":"#authorization#"} ==>  {"Authorization":"OU1v6w9v6zbxzG0T4ntkVy5ZY.SALES"}
    """
    pattern = f"{mark}(.*?){mark}"
    ctx = Context()
    # 判断是否有符合条件的字符串
    while re.search(pattern, target):
        # 匹配
        key = re.search(pattern, target).group(1)
        value = getattr(ctx, key, '')
        target = re.sub(pattern, value, target, 1)
    return target


if __name__ == '__main__':
    pass

