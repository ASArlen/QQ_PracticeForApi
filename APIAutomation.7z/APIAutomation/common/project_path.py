"""
项目路径配置
"""
import os
from time import sleep


class ProjectPath:
    # 项目路径
    ROOT_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    # 测试用例数据的路径
    DATA_PATH = os.path.join(ROOT_PATH, 'test_data')
    # 配置文件路径
    CONFIG_PATH = os.path.join(ROOT_PATH, 'config')
    # 测试用例方法路径
    CASE_PATH = os.path.join(ROOT_PATH, 'test_case')
    # 测试报告路径
    REPORT_PATH = os.path.join(ROOT_PATH, 'report')
    # templates路径
    TEMPLATES_PATH = os.path.join(ROOT_PATH, 'templates')
    # 如果没有改文件夹，自动创建
    if not os.path.exists(REPORT_PATH):
        os.mkdir(REPORT_PATH)
    # 日志方法路径
    LOG_PATH = os.path.join(ROOT_PATH, 'log')
    if not os.path.exists(LOG_PATH):
        os.mkdir(LOG_PATH)


p_path = ProjectPath()

