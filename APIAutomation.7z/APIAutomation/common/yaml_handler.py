# !/usr/bin/python
# -*- coding: utf-8 -*-
import os
import yaml
from common.project_path import p_path


class YamlData:
    __instance = None
    yaml_data = None

    def __init__(self, file):
        self.yaml_path = file

    def __new__(cls, *args, **kwargs):
        if not cls.__instance:
            cls.__instance = super().__new__(cls)
        return cls.__instance

    @property  # 设置属性，调用read_data法时可通过调用属性，不需要带括号
    def read_data(self):
        with open(file=self.yaml_path, mode="rb") as f:
            self.yaml_data = yaml.load(f, Loader=yaml.FullLoader)
        return self.yaml_data

    def save_data(self, data, path=None):
        if not path:
            # 写入数据：
            # data = {"S_data": {"test1": "hello"}, "Sdata2": {"name": "汉字"}}
            with open(file=self.yaml_path, mode="w") as f:
                yaml.dump(data, f, encoding='utf-8', allow_unicode=True)
        else:
            with open(file=path, mode="w") as f:
                yaml.dump(data, f, encoding='utf-8', allow_unicode=True)
        self.yaml_data = data


yaml_path = (os.path.join(p_path.CONFIG_PATH, 'config.yaml'))
yaml_handle = YamlData(yaml_path)
yaml_data = YamlData(yaml_path).read_data
# yaml_handle.save_data(yaml_data)
