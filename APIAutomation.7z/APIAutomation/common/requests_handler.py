"""
requests 二次封装
"""
from common.logger_handler import logger
import requests
import threading


class RequestsHandler:
    _instance_lock = threading.Lock()

    @classmethod
    def instance(cls):
        if not hasattr(RequestsHandler, "_instance"):
            with RequestsHandler._instance_lock:
                if not hasattr(RequestsHandler, "_instance"):
                    RequestsHandler._instance = RequestsHandler()
        return RequestsHandler._instance

    def get(self, url, params=None, api_name=None, **kw):
        """发送get请求"""
        try:
            res = requests.get(url, params=params,**kw)
        except Exception as e:
            # 记录日志信息
            logger.error(f"【{api_name}】访问不成功,报错是:{e}")
        else:
            return res

    def post(self, url, data=None, json=None, api_name=None, **kw):
        """发送 post 请求"""
        try:
            res = requests.post(url, data=data, json=json, **kw)
        except Exception as e:
            # 记录日志信息
            logger.error(f"【{api_name}】访问不成功,报错是:{e}")
        else:
            return res

    def put(self, url, data=None, json=None, api_name=None, **kw):
        """发送 put 请求"""
        try:
            res = requests.put(url, data=data, json=json, **kw)
        except Exception as e:
            # 记录日志信息
            logger.error(f"【{api_name}】访问不成功,报错是:{e}")
        else:
            return res

    def delete(self, url, data=None, json=None, api_name=None, **kw):
        """发送 post 请求"""
        try:
            res = requests.delete(url, data=data, json=json, **kw)
        except Exception as e:
            # 记录日志信息
            logger.error(f"【{api_name}】访问不成功,报错是:{e}")
        else:
            return res

    def visit(self, method, url, params=None, data=None, json=None, api_name=None, **kw):
        """访问接口"""
        if method.lower() == 'get':
            res = self.get(url, params=params, api_name=api_name, **kw)
            return res
        elif method.lower() == 'post':
            return self.post(url, data=data, json=json, params=params, api_name=api_name, **kw)
        elif method.lower() == 'put':
            res = self.put(url, data=data, json=json, params=params, api_name=api_name, **kw)
            return res
        elif method.lower() == 'delete':
            res = self.delete(url, params=params, api_name=api_name, **kw)
            return res
        else:
            # requests 通用的访问方式
            return requests.request(method, url, **kw)

    def json(self, method, url, params=None, data=None, json=None, api_name=None, json_flag=True, **kw):
        """访问接口，获取 json 数据"""

        # 获取json 数据
        try:
            res = self.visit(method, url, params=params, data=data, json=json, api_name=api_name, **kw)
            if json_flag:
                return res.json()
            else:
                return res
        except Exception as e:
            # 记录日志信息
            logger.warning(f"【{api_name}】接口实际返回不是 json 格式的数据,报错是{e}")


class RequestsCookieHandler:

    def __init__(self):
        self.session = requests.Session()

    def get(self, url, params=None, **kw):
        """发送get请求"""
        # http://:baidu
        try:
            res = self.session.get(url, params=params, **kw)
        except Exception as e:
            # 记录日志信息
            logger.error("访问不成功")
        else:
            return res

    def post(self, url, data=None, json=None, **kw):
        """发送 post 请求"""
        try:
            res = self.session.post(url, data=data, json=json, **kw)
        except Exception as e:
            # 记录日志信息
            logger.error("访问不成功")
        else:
            return res

    def visit(self, method, url, params=None, data=None, json=None, **kw):
        """访问接口"""
        if method.lower() == 'get':
            res = self.get(url, params=params, **kw)
            return res
        elif method.lower() == 'post':
            return self.post(url, data=data, json=json, params=params, **kw)
        else:
            # requests 通用的访问方式
            return self.session.request(method, url, **kw)

    def json(self, method, url, params=None, data=None, json=None, **kw):
        """访问接口，获取 json 数据"""
        res = self.visit(method, url, params=params, data=data, json=json, **kw)
        # 获取json 数据
        try:
            return res.json()
        except:
            # 记录日志信息
            logger.error("不是 json 格式的数据")


if __name__ == '__main__':
    pass
