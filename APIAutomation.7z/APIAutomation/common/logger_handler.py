# """
# 日志模块封装
# """
#
# import logging
# import os
# # from colorlog import colorlog
# import logging
# from common.common_fun import CommomFun
# from common.project_path import p_path
# from common.yaml_handler import yaml_data
#
# class LoggerHandler:
#
#     def __init__(self):    # 删除旧的日志文件
#         # try:
#         #     os.remove(os.path.join(p_path.LOG_PATH, 'runlog.log'))
#         # except Exception as e:
#         #     print(f'日志文件删除失败 报错是{e}')
#
#         # 记录器初始化
#         logger = logging.getLogger(yaml_data['log_info']['logger_user']['name'])
#         # 设置记录器收集日志级别
#         logger.setLevel(yaml_data['log_info']['logger_user']['level'])
#         # 控制台日志处理器设置
#         con_handler = logging.StreamHandler()
#         # 控制台处理器设级别设置
#         con_handler.setLevel(yaml_data['log_info']['console_handler']['level'])
#         # 日志格式设置
#         # 控制台输出带日志 级别高的日志颜色改变
#         # con_formatter = colorlog.ColoredFormatter(yaml_data['log_info']['console_handler']['formatter'],
#         #                                           log_colors=yaml_data['log_info']['console_handler']['color'])
#         con_formatter = logging.Formatter(yaml_data['log_info']['console_handler']['formatter'])
#                                                   # log_colors=yaml_data['log_info']['console_handler']['color'])
#         con_handler.setFormatter(con_formatter)
#         logger.addHandler(con_handler)
#
#         # 文件日志处理器设置 按year.month格式输出日志
#         # file_handler = logging.FileHandler(os.path.join(p_path.LOG_PATH, f'runlog{l_year}.{l_month}.log'),
#         tools = CommomFun()
#         log_name = tools.get_now_time()[:10]
#         file_handler = logging.FileHandler(os.path.join(p_path.LOG_PATH, f'{log_name}.log'),
#                                            yaml_data['log_info']['file_handler']['mode'],
#                                            encoding=yaml_data['log_info']['file_handler']['encoding'])
#         file_handler.setLevel(yaml_data['log_info']['file_handler']['level'])
#         file_formatter = logging.Formatter(yaml_data['log_info']['file_handler']['formatter'])
#         file_handler.setFormatter(file_formatter)
#         logger.addHandler(file_handler)
#
#         self.logger = logger
#
#     def debug(self, msg, *args, **kwargs):
#         self.logger.debug(msg, *args, **kwargs)
#
#     def info(self, msg, *args, **kwargs):
#         self.logger.info(msg, *args, **kwargs)
#
#     def warning(self, msg, *args, **kwargs):
#         self.logger.warning(msg, *args, **kwargs)
#
#     def error(self, msg, *args, **kwargs):
#         self.logger.error(msg, *args, **kwargs)
#
#     def critical(self, msg, *args, **kwargs):
#         self.logger.critical(msg, *args, **kwargs)
#
# logger = LoggerHandler().logger
#
# if __name__ == '__main__':
#     pass



import logging


def Log():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s-%(name)s-%(levelname)s-%(message)s')
    logger = logging.getLogger('automation')
    return logger


# 提供单例使用
# logger = Log()
logger = Log()
if __name__ == '__main__':
    logger = Log()
    n = 'abc'
    logger.info('automation test log:%s' % n)
