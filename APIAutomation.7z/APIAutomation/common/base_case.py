# !/usr/bin/python
# -*- coding: utf-8 -*-
import json
import re
import unittest

from jsonpath import jsonpath

from common.logger_handler import logger
from common.param_replace import replace_label
from common.requests_handler import RequestsHandler


class APICase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.req = RequestsHandler()

    def setUp(self) -> None:
        logger.info('<!-------------------------->')


    @classmethod
    def extract(cls, extractor, json_response):
        """
        根据excel数据中extractor列 中的jsonpath表达式，提取json_response中的数据，赋值给jsonpath表达式对应的key值设置的动态参数
        数据示例 ：{"roundList_status":"$..status","roundList_id":"$..id"}
        :param extractor:
        :param json_response:
        :return:
        """
        for prop_name, jsonpath_expression in extractor.items():
            value = jsonpath(json_response, jsonpath_expression)[0]
            # doc/dic/edit接口参数管理时需要去掉base64code元素，特殊处理
            if prop_name == 'editDataDeleteBase64code':
                value.pop("base64code")
                value = json.dumps(value, ensure_ascii=False)
            elif not isinstance(value, str):
                value = str(value)
            setattr(cls, prop_name, value)

    @classmethod
    def replace(cls, target, mark='#'):
        """
        数据替换，先调用getattr获取测试类是否有#test#命名的变量，如果有替换数据，
        再调用replace_label方法获取配置文件是否有#test#命名的变量，如果有替换数据，
        :param target: 传入字符串，替换#test#命名的数据
        :param mark:
        :return:
        """
        pattern = f"{mark}(.*?){mark}"
        # 判断是否有符合条件的字符串
        while re.search(pattern, target):
            # 匹配
            key = re.search(pattern, target).group(1)
            value = str(getattr(cls, key, ''))
            if value != '':
                target = re.sub(pattern, value, target, 1)
        target = replace_label(target)
        return target