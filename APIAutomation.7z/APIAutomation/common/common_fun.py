# !/usr/bin/python
# -*- coding: utf-8 -*-
"""
    公共方法
"""
import os
import random
import time
import datetime
from common.project_path import p_path


class CommomFun(object):
    __instance = None

    def __new__(cls, *args, **kwargs):
        if not cls.__instance:
            cls.__instance = super().__new__(cls)
        return cls.__instance

    def __init__(self):
        self.time_formate = '%Y-%m-%d %H:%M:%S'

    # 获取当前日期
    def now(self):
        return datetime.datetime.now()

    def get_now_time(self):
        return time.strftime(self.time_formate)

    # 获取延后几天日期 默认1天
    def get_dealy_time(self, days=1):
        return (self.now() + datetime.timedelta(days=days)).strftime(self.time_formate)

    def get_before_time(self, days=1):
        return (self.now() - datetime.timedelta(days=days)).strftime(self.time_formate)

    def get_timestamp(self):
        """获取当前时间戳"""
        return str(int(time.time()))

    # 去掉字符串中的空格和\n
    def clear_text(self, text, clear_blank=False):
        try:
            if clear_blank:
                tmp = text.replace(' ', '')
                tmp = tmp.replace('\n', '')
            else:
                tmp = text.replace('\n', '')
        except Exception as e:
            return text
        else:
            return tmp

    # 随机字符串
    def random_str(self, str_lenth=13):
        seed = "1234567890abcdefghijklmnopqrstuvwxyz"
        tmp = []
        for i in range(str_lenth):
            tmp.append(random.choice(seed))
        return ''.join(tmp)

    def delete_log(self):
        print(f'----delete_log----日志文件夹下文件：{os.listdir(p_path.LOG_PATH)}')
        print(f'----delete_log----当前时间：{self.get_now_time()}')
        print(f'----delete_log----当前日期：{self.get_now_time()[:10]}')
        for file_name in os.listdir(p_path.LOG_PATH):
            if file_name.split('.')[0] != self.get_now_time()[:10]:
                os.remove(os.path.join(p_path.LOG_PATH, file_name))

    def get_log_path(self):
        for file_name in os.listdir(p_path.LOG_PATH):
            if file_name.split('.')[0] == self.get_now_time()[:10]:
                return os.path.join(p_path.LOG_PATH, file_name)
            else:
                return None